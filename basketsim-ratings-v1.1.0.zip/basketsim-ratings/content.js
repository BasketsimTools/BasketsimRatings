(() => {
  'use strict';

  const OUTPUT_CLASS = 'bs-ratings-extension';
  const SKILL_NAMES = {
    handling: ['handling', 'ballhandling'],
    quickness: ['quickness'],
    passing: ['passing'],
    dribbling: ['dribbling'],
    rebounds: ['rebounds', 'rebounding'],
    positioning: ['positioning'],
    shooting: ['shooting'],
    freethrows: ['freethrows', 'free throws', 'freethrow'],
    defense: ['defense']
  };

  // Excel: AE = G+H+I+J+K+L+M+N+O; R-V = position formulas.
  const FORMULAS = {
    SUM: ['handling', 'quickness', 'passing', 'dribbling', 'rebounds', 'positioning', 'shooting', 'freethrows', 'defense'],
    PG: ['handling', 'quickness', 'passing', 'defense'],
    SG: ['dribbling', 'quickness', 'defense', 'shooting'],
    SF: ['shooting', 'positioning', 'defense', 'passing'],
    PF: ['passing', 'rebounds', 'positioning', 'defense'],
    C: ['quickness', 'defense', 'rebounds', 'positioning']
  };

  function normalize(text) {
    return text.toLowerCase().replace(/[.:]/g, '').replace(/\s+/g, ' ').trim();
  }

  function skillKey(label) {
    const value = normalize(label);
    return Object.keys(SKILL_NAMES).find((key) => SKILL_NAMES[key].includes(value));
  }

  function numberFromText(text) {
    const matches = String(text).match(/\((\d+)\)/g);
    if (!matches || !matches.length) return null;
    return Number(matches[matches.length - 1].replace(/\D/g, ''));
  }

  function readSkills(table) {
    const skills = {};
    table.querySelectorAll('tr').forEach((row) => {
      const cells = [...row.children].filter((cell) => cell.tagName === 'TD');
      for (let i = 0; i + 1 < cells.length; i += 2) {
        const label = cells[i].querySelector('b')?.textContent || '';
        const key = skillKey(label);
        const value = numberFromText(cells[i + 1].textContent);
        if (key && Number.isInteger(value)) skills[key] = value;
      }
      // Detail pages put label and value in the same TD.
      cells.forEach((cell) => {
        const label = cell.querySelector('b')?.textContent || '';
        const key = skillKey(label);
        const value = numberFromText(cell.textContent);
        if (key && Number.isInteger(value)) skills[key] = value;
      });
    });
    return skills;
  }

  function calculate(skills) {
    const result = {};
    for (const [name, inputs] of Object.entries(FORMULAS)) {
      if (inputs.every((key) => Number.isInteger(skills[key]))) {
        result[name] = inputs.reduce((sum, key) => sum + skills[key], 0);
      }
    }
    return result;
  }

  function createRatings(results) {
    const wrapper = document.createElement('div');
    wrapper.className = OUTPUT_CLASS;
    wrapper.setAttribute('aria-label', 'Basketsim calculated ratings');
    wrapper.innerHTML = '<span class="bs-ratings-title">Ratings</span>' +
      Object.entries(results).map(([name, value]) =>
        `<span class="bs-rating"><b>${name}</b> ${value}</span>`).join('');
    return wrapper;
  }

  function addForTable(table) {
    if (table.nextElementSibling?.classList.contains(OUTPUT_CLASS)) return;
    const results = calculate(readSkills(table));
    if (Object.keys(results).length !== Object.keys(FORMULAS).length) return;
    table.insertAdjacentElement('afterend', createRatings(results));
  }

  function scan() {
    document.querySelectorAll('table.squad-skills, table.player-skills, table.market-result-skills').forEach(addForTable);
  }

  scan();
  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });
})();
